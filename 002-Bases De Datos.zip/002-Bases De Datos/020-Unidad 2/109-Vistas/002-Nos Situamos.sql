SHOW DATABASES;
USE Empresadam2627;

SHOW TABLES;

DESCRIBE Clientes;
DESCRIBE Pedidos;
DESCRIBE Productos;

SELECT * From Clientes;

SELECT * From Productos;

SELECT * From Pedidos;
