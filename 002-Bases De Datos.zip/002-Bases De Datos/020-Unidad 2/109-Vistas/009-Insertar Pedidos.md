Insertar pedido:
INSERT INTO Productos VALUES(
	'[fecha]',
  [numerodepedido],
  [id de cliente],
  [id de producto],
  NULL
);

