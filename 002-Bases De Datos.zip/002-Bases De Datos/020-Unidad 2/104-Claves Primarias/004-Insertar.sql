INSERT INTO Clientes VALUES(
	'Christian',
  'Egea Laparra',
  '535252354',
  'info@jocarsa.com',
  NULL
);

SELECT * FROM Clientes;

