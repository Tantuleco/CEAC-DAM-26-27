TRUNCATE Clientes;
