sudo mysql -u root -p

SHOW DATABASES;

CREATE DATABASE Seleccion;

USE Seleccion;

