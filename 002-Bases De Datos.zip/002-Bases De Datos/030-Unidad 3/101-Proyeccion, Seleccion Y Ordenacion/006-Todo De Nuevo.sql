SELECT * FROM clientes;

