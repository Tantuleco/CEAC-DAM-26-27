SELECT * FROM clientes;

DELETE FROM clientes
WHERE 
apellidos = 'Egea Laparra'
AND
email = 'noaano633@gmail.com';
