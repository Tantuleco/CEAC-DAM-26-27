INSERT INTO clientes 
(email,id,apellidos,nombre)
VALUES
("ddivad633@gmail.com",NULL,"Tortajada","David");

SELECT * FROM clientes;
