sudo mysql -u root -p

CREATE DATABASE Tratamiento;

USE Tratamiento;

CREATE TABLE clientes(
	id INT PRIMARY KEY AUTO_INCREMENT,
	nombre VARCHAR(100),
  apellidos VARCHAR(100),
  email VARCHAR(100)
);

DESCRIBE clientes;

SELECT * FROM clientes;
