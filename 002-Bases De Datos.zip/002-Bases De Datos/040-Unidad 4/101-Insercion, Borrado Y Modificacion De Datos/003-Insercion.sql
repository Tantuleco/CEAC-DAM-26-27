INSERT INTO clientes 
(id,nombre,apellidos,email)
VALUES
(NULL,"David","Tortajada Garcia","ddivad633@gmail.com");

SELECT * FROM clientes;
