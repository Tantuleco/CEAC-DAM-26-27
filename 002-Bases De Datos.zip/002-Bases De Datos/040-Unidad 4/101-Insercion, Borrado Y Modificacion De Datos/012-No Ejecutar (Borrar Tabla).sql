DELETE FROM clientes;
