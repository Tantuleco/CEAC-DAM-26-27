TRUNCATE clientes;

-- Cuidado porque vacía la tabla
