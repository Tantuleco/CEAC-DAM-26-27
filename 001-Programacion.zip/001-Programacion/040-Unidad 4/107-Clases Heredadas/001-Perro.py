class Perro():
  def __init__(self):
    self.edad = 0
    self.color = ""
    self.nombre = ""
