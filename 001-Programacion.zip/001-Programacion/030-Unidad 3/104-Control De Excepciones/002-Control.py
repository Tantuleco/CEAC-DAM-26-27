print("Empiezo el programa")

try:
  print(10/1)
except Exception as e:
  print(e)

print("Acabo el programa")
