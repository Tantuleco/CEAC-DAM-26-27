while True:
	print("1.-Insertar  registro")
  print("2.-Leer registro")
	opcion = input("Introduce tu opcion: ")
  if opcion == "1":
    print("Voy a insertar")
  elif opcion == "2":
    print("Voy a listar")
