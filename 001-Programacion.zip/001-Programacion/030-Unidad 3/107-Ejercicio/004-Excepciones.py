while True:
    print("1.-Insertar registro")
    print("2.-Leer registro")

    opcion = input("Introduce tu opcion: ")
		alumnos = []
    try:
        if opcion == "1":
            print("Voy a insertar")
            alumno = input("Introdu)
        elif opcion == "2":
            print("Voy a listar")
    except Exception as e:
        print("No válido")
