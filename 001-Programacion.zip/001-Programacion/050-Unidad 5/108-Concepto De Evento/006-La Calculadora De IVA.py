# sudo apt update && sudo apt install python3-tk -y
# sudo apt install python3-tk -y
import tkinter as tk

def calcula():
  print("Vamos A Calcular")
  base_imp = base.get()
  base_imp = float(base_imp) 
  iva = base_imp*0.21
  resultado.config(text=iva)

ventana = tk.Tk()
ventana.geometry("800x700")

# entradas de datos
etiqueta = tk.Label(text="Dime La Base Imponible")
etiqueta.pack(padx=10,pady=10)

base = tk.Entry()
base.pack(padx=10,pady=10)

# Dispara la acción
boton = tk.Button(text="Vamos A Calcular El IVA",command=calcula)
boton.pack(padx=10,pady=10)

# Solemos usar label para sacar el resultado
resultado = tk.Label(text="Resultado")
resultado.pack(padx=10,pady=10)
 
ventana.mainloop() # no te salgas, bucle infinito
