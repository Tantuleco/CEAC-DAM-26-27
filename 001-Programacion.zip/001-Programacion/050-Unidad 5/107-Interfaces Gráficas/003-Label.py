# sudo apt update && sudo apt install python3-tk -y
# sudo apt install python3-tk -y
import tkinter as tk

ventana = tk.Tk()
ventana.geometry("600x500")

etiqueta = tk.Label(text="Hola mundo en Tkinter")
etiqueta.pack()
 
ventana.mainloop() # no te salgas, bucle infinito
