import os

os.mkdir("Micarpeta")
