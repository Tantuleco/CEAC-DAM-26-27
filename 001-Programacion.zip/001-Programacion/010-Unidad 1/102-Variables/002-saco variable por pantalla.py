edad = 20 # Solo meto el valor 48 en la memoria
print(edad)
