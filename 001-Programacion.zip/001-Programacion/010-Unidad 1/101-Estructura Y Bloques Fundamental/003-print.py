print("empezamos con Python")
