# Presentacion
print("Programa de clase v0.1")
# Condiciones globales
tiempo_en_carretera = 0
velocidad = 0
# El usuario introduce datos
tiempo_en_carretera = input("Introduce el tiempo que llevas conduciendo: ")
velocidad = input("Introduce la velocidad a la que vas: ")

tiempo_en_carretera = float(tiempo_en_carretera)
velocidad = int(velocidad)
print(tiempo_en_carretera+velocidad)

# El programa hace calculos

# El programa ofrece resultados
