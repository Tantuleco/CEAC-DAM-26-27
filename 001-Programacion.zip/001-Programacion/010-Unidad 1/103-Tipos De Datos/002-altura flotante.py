edad = 20
print(edad)
print(type(edad))

altura = 1.78
print(altura)
print(type(altura))

