"""
	Calculadora de IVA
  Versión 0.1
  por Christian Egea
"""
